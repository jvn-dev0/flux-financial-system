// theme_manager.js - Runs immediately in <head> to prevent FOUC
(function() {
    // Check localStorage, default to 'dark' for the Advanced UI look
    const savedTheme = localStorage.getItem('appTheme') || 'dark';
    document.documentElement.setAttribute('data-theme', savedTheme);
})();
